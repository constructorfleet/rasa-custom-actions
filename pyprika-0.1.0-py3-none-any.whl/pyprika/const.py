"""Constants for use throughout package."""

BASE_URL = 'https://www.paprikaapp.com/api/v1/sync/'

CLIENT_USER_AGENT = 'Pyprika Python Library'
APPLICATION_JSON = 'application/json'
